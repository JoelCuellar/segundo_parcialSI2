import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/dashboard_models.dart';

class DashboardService {
  final String baseUrl;
  final String token;

  DashboardService({
    required this.baseUrl,
    required this.token,
  });

  Future<List<DashboardAlumno>> getDashboardTutor() async {
    try {
      // Según la captura de pantalla, parece que la ruta podría ser diferente
      // Intentemos con las rutas que podrían existir
      final possibleEndpoints = [
        '/api/dashboard-tutor/',
        '/api/dashboard/tutor/',
        '/dashboard-tutor/',
        '/dashboard/tutor/',
        '/usuarios/dashboard-tutor/',
      ];

      Exception? lastError;
      
      // Intentar con diferentes endpoints
      for (final endpoint in possibleEndpoints) {
        try {
          final response = await http.get(
            Uri.parse('$baseUrl$endpoint'),
            headers: {
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
          );

          if (response.statusCode == 200) {
            final data = json.decode(response.body);
            
            // Verificar la estructura de la respuesta
            if (data is Map && data.containsKey('alumnos')) {
              return (data['alumnos'] as List)
                  .map((e) => DashboardAlumno.fromJson(e))
                  .toList();
            } else if (data is List) {
              return data.map((e) => DashboardAlumno.fromJson(e)).toList();
            } else {
              throw Exception('Formato de respuesta inesperado');
            }
          }
        } catch (e) {
          lastError = Exception('Error al cargar el dashboard: $e');
        }
      }
      
      // Si llegamos aquí, ningún endpoint funcionó
      throw lastError ?? Exception('No se pudo conectar con el servidor');
    } catch (e) {
      throw Exception('Error al cargar el dashboard: $e');
    }
  }

  Future<Map<String, dynamic>> getDashboardAlumnoData() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/academico/dashboard-alumno/'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        throw Exception('Error al cargar el dashboard: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error al cargar el dashboard: $e');
    }
  }
  
  // Método para obtener notas por gestión
  Future<Map<String, dynamic>> getNotasPorGestion() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/academico/notas-por-gestion/'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        throw Exception('Error al cargar las notas: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error al cargar las notas: $e');
    }
  }
}
